package dao;

import dto.Categoria;
import dto.Direccion;
import dto.Pedido;
import dto.Producto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class ProductoDAO extends TablaDAO<Producto>{
    public ProductoDAO() {
        this.tabla = "DAVE_PRODUCTO";
    }

    @Override
    public int actualizar(Producto p) throws SQLException {
        String sentenciaSQL = "UPDATE " + tabla + " SET fechaCreacion=?, precio=?, codigo=?, ultimaModificacion=?, unidades=?, descripcion=?, nombre=?, cantidadDesponible=?, stockMinimo=?, rutaFoto=?, categoria=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        LocalDateTime fechaCreacion = p.getFechaCreacion();
        if (fechaCreacion == null) {
            prepared.setNull(1, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(1, Timestamp.valueOf(fechaCreacion));
        }
        
        prepared.setDouble(2, p.getPrecio());
        prepared.setInt(3, p.getCodigo());
        LocalDateTime ultimaModificacion = p.getUltModificacion();
        if (ultimaModificacion == null) {
            prepared.setNull(4, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(4, Timestamp.valueOf(ultimaModificacion));
        }
        prepared.setInt(5, p.getUnidades());
        prepared.setString(6, p.getDescripcion());
        prepared.setString(7, p.getNombre());
        prepared.setInt(8, p.getCantidadDisponible());
        prepared.setInt(9, p.getStockMinimo());
        if (p.getImg() == null) {
            prepared.setNull(10, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(10, p.getImg());
        }
        prepared.setString(11, String.valueOf(p.getCategoria()));
        int resultado = prepared.executeUpdate();
        return resultado;
    }

    @Override
    public int anyadir(Producto p) throws SQLException {
        // Falta el 5 que es el array list de producto
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        LocalDateTime fechaCreacion = p.getFechaCreacion();
        if (fechaCreacion == null) {
            prepared.setNull(1, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(1, Timestamp.valueOf(fechaCreacion));
        }
        prepared.setDouble(2, p.getPrecio());
        prepared.setInt(3, p.getCodigo());
        LocalDateTime ultimaModificacion = p.getUltModificacion();
        if (ultimaModificacion == null) {
            prepared.setNull(4, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(4, Timestamp.valueOf(ultimaModificacion));
        }
        prepared.setInt(5, p.getUnidades());
        prepared.setString(6, p.getDescripcion());
        prepared.setString(7, p.getNombre());
        prepared.setInt(8, p.getCantidadDisponible());
        prepared.setInt(9, p.getStockMinimo());
        prepared.setString(10, p.getImg());
        prepared.setString(11, String.valueOf(p.getCategoria()));
        return prepared.executeUpdate();
    }
    
    @Override
    public Producto eliminar(Producto p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCodigo()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Producto p) throws SQLException {
        return existe(p.getCodigo());
    }

    @Override
    public ArrayList<Producto> getAll() throws SQLException {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            LocalDateTime fechaCreacion = resultSet.getTimestamp("fechaCreacion").toLocalDateTime();
            double precio = resultSet.getInt("precio");
            int codigo = resultSet.getInt("codigo");
            Timestamp fechaModificacionTS = resultSet.getTimestamp("ultimaModificacion");
            LocalDateTime ultimaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            int unidades = resultSet.getInt("unidades");
            String descripcion = resultSet.getString("descripcion");
            String nombre = resultSet.getString("nombre");
            int cantidadDisponible = resultSet.getInt("cantidadDisponible");
            int stockMinimo = resultSet.getInt("stockMinimo");
            String img = resultSet.getString("rutaFoto");
            Categoria categoria = Categoria.valueOf(resultSet.getString("categoria"));
            lista.add(new Producto(fechaCreacion, precio,codigo,ultimaModificacion,unidades, descripcion,nombre,cantidadDisponible,stockMinimo,img,categoria));
        }

        return lista;
    }
    
    @Override
    public Producto getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            LocalDateTime fechaCreacion = resultSet.getTimestamp("fechaCreacion").toLocalDateTime();
            double precio = resultSet.getInt("precio");
            Timestamp fechaModificacionTS = resultSet.getTimestamp("ultimaModificacion");
            LocalDateTime ultimaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            int unidades = resultSet.getInt("unidades");
            String descripcion = resultSet.getString("descripcion");
            String nombre = resultSet.getString("nombre");
            int cantidadDisponible = resultSet.getInt("cantidadDisponible");
            int stockMinimo = resultSet.getInt("stockMinimo");
            String img = resultSet.getString("rutaFoto");
            Categoria categoria = Categoria.valueOf(resultSet.getString("categoria"));
            return new Producto(fechaCreacion, precio,codigo,ultimaModificacion,unidades, descripcion,nombre,cantidadDisponible,stockMinimo,img,categoria);
        }

        return null;
    }
    
    public ArrayList<Producto> getProductoByCategoria(Categoria categoria) throws SQLException {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE categoria=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, categoria.toString());
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            LocalDateTime fechaCreacion = resultSet.getTimestamp("fechaCreacion").toLocalDateTime();
            double precio = resultSet.getInt("precio");
            int codigo = resultSet.getInt("codigo");
            Timestamp fechaModificacionTS = resultSet.getTimestamp("ultimaModificacion");
            LocalDateTime ultimaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            int unidades = resultSet.getInt("unidades");
            String descripcion = resultSet.getString("descripcion");
            String nombre = resultSet.getString("nombre");
            int cantidadDisponible = resultSet.getInt("cantidadDisponible");
            int stockMinimo = resultSet.getInt("stockMinimo");
            String img = resultSet.getString("rutaFoto");
            lista.add(new Producto(fechaCreacion, precio,codigo,ultimaModificacion,unidades, descripcion,nombre,cantidadDisponible,stockMinimo,img,categoria));
        }

        return lista;
    }
    
    public ArrayList<Producto> getSlider() throws SQLException{
        ArrayList<Producto> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE ROWNUM <= 4";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            LocalDateTime fechaCreacion = resultSet.getTimestamp("fechaCreacion").toLocalDateTime();
            double precio = resultSet.getInt("precio");
            int codigo = resultSet.getInt("codigo");
            Timestamp fechaModificacionTS = resultSet.getTimestamp("ultimaModificacion");
            LocalDateTime ultimaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            int unidades = resultSet.getInt("unidades");
            String descripcion = resultSet.getString("descripcion");
            String nombre = resultSet.getString("nombre");
            int cantidadDisponible = resultSet.getInt("cantidadDisponible");
            int stockMinimo = resultSet.getInt("stockMinimo");
            String img = resultSet.getString("rutaFoto");
            Categoria categoria = Categoria.valueOf(resultSet.getString("categoria"));
            lista.add(new Producto(fechaCreacion, precio,codigo,ultimaModificacion,unidades, descripcion,nombre,cantidadDisponible,stockMinimo,img,categoria));
        }

        return lista;
    }
}
