/*
    Projecte de David Casáñez Sanz i Samuel Bautista Valera
 */
package dto;
public class Projecte {
    public static void main(String[] args) {
        //Açí s'afegirà el codi
    }
    
}
