package dao;

import dto.Direccion;
import dto.Producto;
import dto.TipoUsuario;
import dto.Usuario;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Test {
    public static void main(String[] args)  {
        try {
            Producto pro = new ProductoDAO().getByCodigo(1);
            System.out.println(pro.toString());
        } catch (SQLException ex) {
            System.out.println("Error");
        }
        
        try {
            Usuario u = new Usuario(2, "samueliki@gmail.com", "Samuel Bautista Valera", "soymuylisto4", LocalDate.of(2003, 7, 23), LocalDateTime.of(2023, 9, 7, 17, 54, 32), "", TipoUsuario.Administrador);
            new UsuarioDAO().anyadir(new Usuario(2, "samueliki@gmail.com", "Samuel Bautista Valera", "soymuylisto4", LocalDate.of(2003, 7, 23), LocalDateTime.of(2023, 9, 7, 17, 54, 32), "", TipoUsuario.Administrador));
            System.out.println(u.toString());
        } catch (SQLException ex) {
            System.out.println("Error");
        }
        
        try {
            Usuario u2 = new UsuarioDAO().getByCodigo(2);
            System.out.println(u2.toString());
        } catch (SQLException ex) {
            System.out.println("Error");
        }

    }
    
}