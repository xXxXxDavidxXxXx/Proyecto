package dao;

import dto.Direccion;
import dto.Pedido;
import dto.Producto;
import dto.Usuario;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class PedidoDAO extends TablaDAO<Pedido>{
    public PedidoDAO() {
        this.tabla = "DAVE_PEDIDO";
    }

    @Override
    public int actualizar(Pedido p) throws SQLException {
        //No necesario para el proyecto
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido p) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.setInt(2, p.getCodigoUsuario().getCodigo());
        prepared.setInt(3, p.getCodigoDireccion().getCodigo());
        LocalDateTime fecha = p.getFecha();
        if (fecha == null) {
            prepared.setNull(4, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(4, Timestamp.valueOf(fecha));
        }
        int resultado = prepared.executeUpdate();
        anyadirLineas(p);
        return resultado;
    }

    @Override
    public Pedido eliminar(Pedido p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCodigo()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Pedido p) throws SQLException {
        return existe(p.getCodigo());
    }

    @Override
    public ArrayList<Pedido> getAll() throws SQLException {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Usuario codigoUsuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            Direccion codigoDireccion = new DireccionDAO().getByCodigo(resultSet.getInt("codigoDireccion"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            lista.add(new Pedido(codigo, codigoUsuario, codigoDireccion,fecha, lineasPedido));
        }

        return lista;
    }
    
    @Override
    public Pedido getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Usuario codigoUsuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            Direccion codigoDireccion = new DireccionDAO().getByCodigo(resultSet.getInt("codigoDireccion"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            return new Pedido(codigo, codigoUsuario, codigoDireccion,fecha, lineasPedido);
        }

        return null;
    }
    
    public ArrayList<Pedido> getByCodigoUsuario(int codigoUsuario) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigoUsuario=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        Usuario usuario = new UsuarioDAO().getByCodigo(codigoUsuario);
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Direccion codigoDireccion = new DireccionDAO().getByCodigo(resultSet.getInt("codigoDireccion"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            pedidos.add(new Pedido(codigo, usuario, codigoDireccion,fecha, lineasPedido));
        }

        return pedidos;
    }
    
    public ArrayList<Pedido> getByCodigoDireccion(int codigoDireccion) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigoDireccion=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoDireccion);
        ResultSet resultSet = prepared.executeQuery();
        Direccion direccion = new DireccionDAO().getByCodigo(codigoDireccion);
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Usuario codigoUsuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            LinkedHashMap<Producto, Integer> lineasPedido = getLineas(codigo);
            pedidos.add(new Pedido(codigo, codigoUsuario, direccion,fecha, lineasPedido));
        }

        return pedidos;
    }
    
    public LinkedHashMap<Producto, Integer> getLineas(int codPedido) throws SQLException {
        ProductoDAO productoDAO = new ProductoDAO();
        LinkedHashMap<Producto, Integer> lineas = new LinkedHashMap<>();
        String sentenciaSQL = "SELECT codigoproducto, cantidadproductos FROM dave_productos_pedido WHERE codigopedido = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codPedido);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Producto producto = productoDAO.getByCodigo(resultSet.getInt("codigoproducto"));
            int cantidad = resultSet.getInt("cantidadproductos");
            lineas.put(producto, cantidad);
        }

        return lineas;

    }
        
    private void anyadirLineas(Pedido p) throws SQLException {
        for (Map.Entry<Producto, Integer> entry : p.getLineasPedido().entrySet()) {
            String sentenciaSQL = "INSERT INTO dave_productos_pedido VALUES(?, ?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, entry.getKey().getCodigo());
            prepared.setInt(2, p.getCodigo());
            prepared.setInt(3, entry.getValue());
            prepared.executeUpdate();
        }
    }
        
    private void eliminarLineas(Pedido p) throws SQLException {
        String sentenciaSQL = "DELETE FROM dave_productos_pedido WHERE codigopedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.executeUpdate();

    }
    
    public void descontarStock(Pedido ped) throws SQLException {
        ProductoDAO productoDAO = new ProductoDAO();
        for (Map.Entry<Producto, Integer> linea : ped.getLineasPedido().entrySet()) {
            try {
                Producto pa = linea.getKey();
                int stock = pa.getUnidades() - linea.getValue();
                Producto pn = new Producto(pa.getFechaCreacion(), pa.getPrecio(),pa.getCodigo(),pa.getUltModificacion(),pa.getUnidades(), pa.getDescripcion(),pa.getNombre(),stock,pa.getStockMinimo(),pa.getImg(),pa.getCategoria());
                productoDAO.actualizar(pn);
            } catch (SQLException ex) {
                System.out.println("Error SQL");
            }
        }
    }
    
    public int ultimoPedido() throws SQLException {
        String sentenciaSQL = "SELECT codigo FROM " + tabla + " WHERE ROWNUM <= 1 ORDER BY codigo DESC";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        int codigo = 0;
         while (resultSet.next()) {
            codigo = resultSet.getInt("codigo");
        }
        
        return codigo;
    }
    
}
