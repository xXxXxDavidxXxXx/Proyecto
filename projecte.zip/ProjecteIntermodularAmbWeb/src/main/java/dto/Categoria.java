package dto;
public enum Categoria {
    
    Planta, Zombie;
}
