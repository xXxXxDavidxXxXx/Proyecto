package dao;
    import java.sql.Date;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.sql.SQLException;
    import java.sql.Timestamp;
    import java.time.LocalDate;
    import java.time.LocalDateTime;
    import java.util.ArrayList;
    import dto.TipoUsuario;
    import dto.Usuario;
public class UsuarioDAO extends TablaDAO<Usuario>{
    
    public UsuarioDAO() {
        this.tabla = "DAVE_USUARIO";
    }

    @Override
    public int actualizar(Usuario u) throws SQLException{
        // NO SE UTILIZA EN NUESTRO PROYECTO
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int anyadir(Usuario u) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        prepared.setString(2, u.getEmail());
        prepared.setString(3, u.getNombre());
        prepared.setString(4, u.getContrasenya());
        prepared.setDate(5, Date.valueOf(u.getFechaNacimiento()));
        LocalDateTime ultimaConexion = u.getUltimaConexion();
        if (ultimaConexion == null) {
            prepared.setNull(6, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(6, Timestamp.valueOf(ultimaConexion));
        }
        if (u.getImg() == null) {
            prepared.setNull(7, java.sql.Types.VARCHAR);
        } else {
            prepared.setString(7, u.getImg());
        }
        prepared.setString(8, String.valueOf(u.getPermisosAdministrador()));
        return prepared.executeUpdate();
    }

    @Override
    public Usuario eliminar(Usuario u) throws SQLException {
        if (u == null) {
            return null;
        } else {
            return eliminar(u.getCodigo()) != null ? u : null;
        }
    }
    
    @Override
    public boolean existe(Usuario u) throws SQLException {
        return existe(u.getCodigo());
    }
    
    @Override
    public ArrayList<Usuario> getAll() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String email = resultSet.getString("email");
            String nombre = resultSet.getString("nombre");
            String contrasenya = resultSet.getString("contrasenya");
            LocalDate fechaNacimiento = resultSet.getDate("fechaNacimiento").toLocalDate();
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultimaConexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            String img = resultSet.getString("img");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            lista.add(new Usuario(codigo, email, nombre, contrasenya, fechaNacimiento, ultimaConexion, img, tipoUsuario));
        }

        return lista;
    }
    
    @Override
    public Usuario getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String email = resultSet.getString("email");
            String nombre = resultSet.getString("nombre");
            String contrasenya = resultSet.getString("contrasenya");
            LocalDate fechaNacimiento = resultSet.getDate("fechaNacimiento").toLocalDate();
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultimaConexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            String img = resultSet.getString("img");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            return new Usuario(codigo, email, nombre, contrasenya, fechaNacimiento, ultimaConexion, img, tipoUsuario);
        }
        
        return null;
    }
    
    public Usuario validar(String formEmail, String formPassword) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email=? AND contrasenya=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, formEmail);
        prepared.setString(2, formPassword);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String email = resultSet.getString("email");
            String nombre = resultSet.getString("nombre");
            String contrasenya = resultSet.getString("contrasenya");
            LocalDate fechaNacimiento = resultSet.getDate("fechaNacimiento").toLocalDate();
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultimaConexion");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            String img = resultSet.getString("img");
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo"));
            return new Usuario(codigo, email, nombre, contrasenya, fechaNacimiento, ultimaConexion, img, tipoUsuario);
        }
        
        return null;
    }
    
    

}
