package controlador;

import dao.DireccionDAO;
import dao.PedidoDAO;
import dao.ProductoDAO;
import dto.Direccion;
import dto.Pedido;
import dto.Producto;
import dto.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class CarritoServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        try ( PrintWriter out = response.getWriter()) {
            Usuario usuarioSesion = (session != null && session.getAttribute("usuario") != null) ? (Usuario) session.getAttribute("usuario") : null; 
            if (usuarioSesion == null) {
                out.println("<h2>No se puede acceder a esta sección sin usuario</h2><p><a href=\"javascript: history.go(-1)\">Volver atrás</a></p>");
            } else {
                // Validamos los datos del formulario
                String strId = request.getParameter("codigo");
                String strCantidad = request.getParameter("cantidad");
                if (strId != null && strCantidad != null) {
                    Producto pro = new ProductoDAO().getByCodigo(Integer.parseInt(strId));

                    int cantidad = Integer.parseInt(strCantidad);
                    //Si existe el carrito en la sesión obtenemos las líneas y añadimos la del formulario
                    LinkedHashMap<Producto, Integer> lineas = new LinkedHashMap<>();
                    Direccion dir = null;
                    if (session.getAttribute("carrito") != null) {
                        Pedido carrito = (Pedido) session.getAttribute("carrito");
                        lineas = new LinkedHashMap<>(carrito.getLineasPedido());
                        dir = carrito.getCodigoDireccion();
                    } //Si no existe el carrito añadimos las líneas desde cero
                    else{
                        dir = new DireccionDAO().getDireccionesDeUno(usuarioSesion.getCodigo());
                    }
                    lineas.putIfAbsent(pro, cantidad);
                    PedidoDAO pedDAO = new PedidoDAO();
                    Pedido ped = new Pedido(pedDAO.ultimoPedido()+1, usuarioSesion, dir, LocalDateTime.now(), lineas);
                    session.setAttribute("carrito", ped);
                    response.sendRedirect("catalogo.jsp");
                } else {
                    out.println("<h2>Datos incorrectos. Revisa el formulario</h2><p><a href=\"javascript: history.go(-1)\">Volver atrás</a></p>");
                }

            }
        } catch (SQLException ex) {
            /*System.out.println("Error SQL");*/
            ex.printStackTrace();
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
