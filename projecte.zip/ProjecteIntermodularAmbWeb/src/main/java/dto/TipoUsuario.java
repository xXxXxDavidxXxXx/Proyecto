package dto;
public enum TipoUsuario {
    
    Administrador, Cliente
}
