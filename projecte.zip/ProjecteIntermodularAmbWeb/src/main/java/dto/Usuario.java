package dto;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;
import java.time.LocalDateTime;
public class Usuario {
    private int codigo;
    private String email;
    private String nombre;
    private String contrasenya;
    private LocalDate fechaNacimiento;
    private LocalDateTime ultimaConexion;
    private String img;
    private TipoUsuario permisosAdministrador;

    public Usuario(int codigo, String email, String nombre, String contrasenya, LocalDate fechaNacimiento, LocalDateTime ultimaConexion, String img, TipoUsuario permisosAdministrador) {
        this.codigo = codigo;
        this.email = email;
        this.nombre = nombre;
        this.contrasenya = contrasenya;
        this.fechaNacimiento = fechaNacimiento;
        this.ultimaConexion = ultimaConexion;
        this.img = img;
        this.permisosAdministrador = permisosAdministrador;
    }

    public Usuario(Usuario u) {
        this(u.codigo, u.email, u.nombre, u.contrasenya, u.fechaNacimiento, u.ultimaConexion, u.img, u.permisosAdministrador);
    }

    public int getCodigo() {
        return codigo;
    }

    public String getEmail() {
        return email;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContrasenya() {
        return contrasenya;
    }
    
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public LocalDateTime getUltimaConexion() {
        return ultimaConexion;
    }
    
    public String getImg() {
        return img;
    }
    
    public TipoUsuario getPermisosAdministrador() {
        return permisosAdministrador;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 61 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", email=" + email + ", nombre=" + nombre + ", contrasenya=" + contrasenya + ", fechaNacimiento=" + fechaNacimiento + ", ultimaConexion=" + ultimaConexion + ", img=" + img + ", permisosAdministrador=" + permisosAdministrador + '}';
    }
    
}
