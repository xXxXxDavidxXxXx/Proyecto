//Única clase que puede dar problemas
package dto;
import java.util.ArrayList;
import java.util.Objects;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

public class Pedido {
    private final int codigo;
    private final Usuario codigoUsuario;
    private final Direccion codigoDireccion;
    private final LocalDateTime fecha;
    private final LinkedHashMap<Producto,Integer> lineasPedido;
    private final double precioTotal;

    public Pedido(int codigo, Usuario codigoUsuario, Direccion codigoDireccion, LocalDateTime fecha, LinkedHashMap<Producto, Integer> lineasPedido) {
        this.codigo = codigo;
        this.codigoUsuario = new Usuario(codigoUsuario);
        this.codigoDireccion = new Direccion(codigoDireccion);
        this.fecha = fecha;
        this.lineasPedido = lineasPedido;
        this.precioTotal = ponerPrecio();
    }
    
    public double ponerPrecio(){
        double precioTotal = 0;
        for(Map.Entry<Producto, Integer> linea: lineasPedido.entrySet()){
            precioTotal += linea.getKey().getPrecio() * linea.getValue();
        }
        return precioTotal;
    }
    
    public LinkedHashMap<Producto, Integer> getLineasPedido() {
        return new LinkedHashMap<>(lineasPedido);
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public int getCodigo() {
        return codigo;
    }

    public Usuario getCodigoUsuario() {
        return codigoUsuario;
    }

    public Direccion getCodigoDireccion() {
        return codigoDireccion;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Pedido{" + "codigo=" + codigo + ", codigoUsuario=" + codigoUsuario + ", codigoDireccion=" + codigoDireccion + ", fecha=" + fecha + ", lineasPedido=" + lineasPedido + '}';
    }
    
    public boolean revisarStock() {
        for(Map.Entry<Producto, Integer> linea: lineasPedido.entrySet()){
            if(linea.getKey().getUnidades() - linea.getValue() < linea.getKey().getStockMinimo()) return false;
        }
        return true;
    }
    
    public boolean perteneceAUsuario(Usuario u){
        return this.codigoUsuario.equals(u);
    }
    
}
