package dao;
    import java.sql.Date;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.sql.SQLException;
    import java.sql.Timestamp;
    import java.time.LocalDate;
    import java.time.LocalDateTime;
    import java.util.ArrayList;
    import dto.Direccion;
import dto.Usuario;

public class DireccionDAO extends TablaDAO<Direccion>{
    
    public DireccionDAO() {
        this.tabla = "DAVE_DIRECCION";
    }
    
    @Override
    public int actualizar(Direccion d) throws SQLException {
        // NO SE UTILIZA EN NUESTRO PROYECTO
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public int anyadir(Direccion d) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, d.getCalle());
        prepared.setInt(2, d.getCodigo());
        prepared.setString(3, d.getnPuerta());
        prepared.setString(4, d.getProvincia());
        prepared.setString(5, d.getTipoVivienda());
        prepared.setInt(6, d.getCodPostal());
        prepared.setString(7, d.getCiudad());
        prepared.setInt(8, d.getUsuario().getCodigo());
        return prepared.executeUpdate();
    }

    @Override
    public Direccion eliminar(Direccion d) throws SQLException {
        if (d == null) {
            return null;
        } else {
            return eliminar(d.getCodigo()) != null ? d : null;
        }
    }

    @Override
    public boolean existe(Direccion d) throws SQLException {
        return existe(d.getCodigo());
    }
    
    @Override
    public ArrayList<Direccion> getAll() throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String calle = resultSet.getString("calle");
            int codigo = resultSet.getInt("codigo");
            String nPuerta = resultSet.getString("nPuerta");
            String provincia = resultSet.getString("provincia");
            String tipoVivienda = resultSet.getString("TipoVivienda");
            int codPostal = resultSet.getInt("codigoPostal");
            String ciudad = resultSet.getString("ciudad");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            lista.add(new Direccion(calle,codigo,nPuerta,provincia,tipoVivienda,codPostal,ciudad,usuario));
        }
        return lista;
    }
    
    @Override
    public Direccion getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";;
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String calle = resultSet.getString("calle");
            String nPuerta = resultSet.getString("nPuerta");
            String provincia = resultSet.getString("provincia");
            String tipoVivienda = resultSet.getString("TipoVivienda");
            int codPostal = resultSet.getInt("codigoPostal");
            String ciudad = resultSet.getString("ciudad");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            return new Direccion(calle,codigo,nPuerta,provincia,tipoVivienda,codPostal,ciudad,usuario);
        }
        return null;
    }
    
    public ArrayList<Direccion> getDireccionesDe(int codigoUsuario) throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigoUsuario=? ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String calle = resultSet.getString("calle");
            int codigo = resultSet.getInt("codigo");
            String nPuerta = resultSet.getString("nPuerta");
            String provincia = resultSet.getString("provincia");
            String tipoVivienda = resultSet.getString("TipoVivienda");
            int codPostal = resultSet.getInt("codigoPostal");
            String ciudad = resultSet.getString("ciudad");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            lista.add(new Direccion(calle,codigo,nPuerta,provincia,tipoVivienda,codPostal,ciudad,usuario));
        }
        return lista;
    }
    
    public Direccion getDireccionesDeUno(int codigoUsuario) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigoUsuario=? AND ROWNUM <= 1 ORDER BY codigo ASC ";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String calle = resultSet.getString("calle");
            int codigo = resultSet.getInt("codigo");
            String nPuerta = resultSet.getString("nPuerta");
            String provincia = resultSet.getString("provincia");
            String tipoVivienda = resultSet.getString("TipoVivienda");
            int codPostal = resultSet.getInt("codigoPostal");
            String ciudad = resultSet.getString("ciudad");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("codigoUsuario"));
            return new Direccion(calle,codigo,nPuerta,provincia,tipoVivienda,codPostal,ciudad,usuario);
        }
        return null;
    }
}
