package dto;

import java.util.Objects;

public class Direccion {
    private String calle;
    private int codigo;
    private String nPuerta;
    private String provincia;
    private String tipoVivienda;
    private int codPostal;
    private String ciudad;
    private Usuario usuario;

    public Direccion(String calle, int codigo, String nPuerta, String provincia, String tipoVivienda, int codPostal, String ciudad, Usuario usuario) {
        this.calle = calle;
        this.codigo = codigo;
        this.nPuerta = nPuerta;
        this.provincia = provincia;
        this.tipoVivienda = tipoVivienda;
        this.codPostal = codPostal;
        this.ciudad = ciudad;
        if(usuario == null) throw new RuntimeException("La dirección debe tener un usuario asociado");
        this.usuario = new Usuario(usuario);
    }

    Direccion(Direccion d) {
        this(d.calle, d.codigo, d.nPuerta, d.provincia, d.tipoVivienda, d.codPostal, d.ciudad, d.usuario);
    }

    public String getCalle() {
        return calle;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getnPuerta() {
        return nPuerta;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getTipoVivienda() {
        return tipoVivienda;
    }

    public int getCodPostal() {
        return codPostal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public Usuario getUsuario() {
        return usuario;
    }
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Direccion other = (Direccion) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Direccion{" + "calle=" + calle + ", codigo=" + codigo + ", nPuerta=" + nPuerta + ", provincia=" + provincia + ", tipoVivienda=" + tipoVivienda + ", codPostal=" + codPostal + ", ciudad=" + ciudad + ", usuario=" + usuario + '}';
    }

    
    
}
