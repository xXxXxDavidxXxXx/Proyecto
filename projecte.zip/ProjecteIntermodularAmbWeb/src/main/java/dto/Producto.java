package dto;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class Producto {
    private LocalDateTime fechaCreacion;
    private double precio;
    private int codigo;
    private LocalDateTime ultModificacion;
    private int unidades;
    private String descripcion;
    private String nombre;
    private int cantidadDisponible;
    private int stockMinimo;
    private String img;
    private Categoria categoria;

    public Producto(LocalDateTime fechaCreacion, double precio, int codigo, LocalDateTime ultModificacion, int unidades, String descripcion, String nombre, int cantidadDisponible, int stockMinimo, String img, Categoria categoria) {
        this.fechaCreacion = fechaCreacion;
        this.precio = precio;
        this.codigo = codigo;
        this.ultModificacion = ultModificacion;
        this.unidades = unidades;
        this.descripcion = descripcion;
        this.nombre = nombre;
        this.cantidadDisponible = cantidadDisponible;
        this.stockMinimo = stockMinimo;
        this.img = img;
        this.categoria = categoria;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDateTime getUltModificacion() {
        return ultModificacion;
    }

    public int getUnidades() {
        return unidades;
    }

    public String getDescripcion() {
        return descripcion;
    }
    
    public String getNombre() {
        return nombre;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public String getImg() {
        return img;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Producto{" + "fechaCreacion=" + fechaCreacion + ", precio=" + precio + ", codigo=" + codigo + ", ultModificacion=" + ultModificacion + ", unidades=" + unidades + ", descripcion=" + descripcion + ", nombre=" + nombre + ", cantidadDisponible=" + cantidadDisponible + ", stockMinimo=" + stockMinimo + ", img=" + img + ", categoria=" + categoria + '}';
    }
    
}
